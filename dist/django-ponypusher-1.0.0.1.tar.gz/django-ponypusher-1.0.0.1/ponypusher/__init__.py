"""Django integration for pusher app"""
VERSION = "1.0.0.1"
